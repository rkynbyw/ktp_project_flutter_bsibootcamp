import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import 'package:project_form_ktp/main.dart';
import 'package:project_form_ktp/presentation/widget/dropdown_location_widget.dart';
// import 'package:project_form_ktp/presentation/widget/dropdown_widget_new.dart';
import 'package:project_form_ktp/datasource/location_datasource.dart';
import 'package:project_form_ktp/entities/location_entity.dart';

class FormPage extends StatelessWidget {

  TextEditingController _namaController = TextEditingController();
  TextEditingController _pendidikanController = TextEditingController();
  TextEditingController _pekerjaanController = TextEditingController();
  TextEditingController _provinceController = TextEditingController();
  TextEditingController _cityController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text('Form Penduduk Page'),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              TextField(
                controller: _namaController,
                decoration: InputDecoration(
                    labelText: 'Nama',
                    hintText: 'Masukkan Nama Anda',
                    prefixIcon: Icon(Icons.person),
                    border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              DropdownWidget(),
              TextField(
                controller: _pendidikanController,
                decoration: InputDecoration(
                  labelText: 'Pendidikan',
                  hintText: 'Masukkan Pendidikan Anda',
                  prefixIcon: Icon(Icons.book),
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _pekerjaanController,
                decoration: InputDecoration(
                    labelText: 'Pekerjaan',
                    hintText: 'Masukkan Pekerjaan Anda',
                    prefixIcon: Icon(Icons.laptop),
                    border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                  onPressed: (){
                    context.go('/list');
                  },
                  child: Text('Add Data')
              ),
              SizedBox(height: 20),
              ElevatedButton(
                  onPressed: (){
                    context.go('/list');
                  },
                  child: Text('View List')
              ),
              SizedBox(height: 20),
            ],
          ),
        )

    );
  }
}