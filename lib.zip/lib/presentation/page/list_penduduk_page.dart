import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:project_form_ktp/presentation/page/form_penduduk_page.dart';

class ListPendudukPage extends StatefulWidget {
  const ListPendudukPage({super.key});

  @override
  State<ListPendudukPage> createState() => _ListPendudukPageState();
}

class _ListPendudukPageState extends State<ListPendudukPage> {

  late final Box userBox;

  @override
  void initState() {
    super.initState();
    userBox = Hive.box('user_box');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('List Penduduk Page'),
        centerTitle: true,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: IconButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => FormPage(),
                ),
              ),
              icon: const Icon(Icons.add),
            ),
          ),

        ],
      ),
      body: ValueListenableBuilder(
          valueListenable: userBox.listenable(),
          builder: (context, value, child){
            if (value.isEmpty){
              return const Center(
                child: Text('Database is Empty'),
              );
            } else {
              return ListView.builder(
                  itemCount: userBox.length,
                  itemBuilder: (context, index){
                    var box = value;
                    var getData = box.getAt(index);

                    return ListTile(
                      leading: IconButton(
                        onPressed: (){

                        },
                        icon: const Icon(Icons.edit),
                      ),
                      title: Text(getData.nama),
                      subtitle: Text(getData.pekerjaan),
                      trailing: IconButton(
                        onPressed: (){

                        },
                        icon: const Icon(Icons.delete),
                      ),
                    );
                  }
              );
            }
          }
      )
    );
  }
}
